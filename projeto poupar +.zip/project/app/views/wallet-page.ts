import { NavigatedData, Page } from '@nativescript/core';
import { WalletViewModel } from '../viewmodels/wallet-view-model';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    page.bindingContext = new WalletViewModel();
}