import { Observable, Frame } from '@nativescript/core';

export class ContactViewModel extends Observable {
    private _name: string = "";
    private _email: string = "";
    private _address: string = "";
    private _phone: string = "";

    constructor() {
        super();
    }

    get name(): string {
        return this._name;
    }

    set name(value: string) {
        if (this._name !== value) {
            this._name = value;
            this.notifyPropertyChange('name', value);
        }
    }

    get email(): string {
        return this._email;
    }

    set email(value: string) {
        if (this._email !== value) {
            this._email = value;
            this.notifyPropertyChange('email', value);
        }
    }

    get address(): string {
        return this._address;
    }

    set address(value: string) {
        if (this._address !== value) {
            this._address = value;
            this.notifyPropertyChange('address', value);
        }
    }

    get phone(): string {
        return this._phone;
    }

    set phone(value: string) {
        if (this._phone !== value) {
            this._phone = value;
            this.notifyPropertyChange('phone', value);
        }
    }

    onSubmit() {
        // Aqui seria implementada a lógica de envio do formulário
        alert({
            title: "Sucesso!",
            message: "Entraremos em contacto consigo em breve.",
            okButtonText: "OK"
        });
        Frame.topmost().goBack();
    }
}