import { Observable, Frame } from '@nativescript/core';

export class WalletViewModel extends Observable {
    private _coinBalance: number = 3500;

    constructor() {
        super();
    }

    get coinBalance(): number {
        return this._coinBalance;
    }

    set coinBalance(value: number) {
        if (this._coinBalance !== value) {
            this._coinBalance = value;
            this.notifyPropertyChange('coinBalance', value);
        }
    }

    onRedeemPrize() {
        alert({
            title: "Confirmação",
            message: "Tem certeza que deseja resgatar este prémio?",
            okButtonText: "Sim",
            cancelButtonText: "Não"
        }).then((result) => {
            if (result) {
                alert({
                    title: "Sucesso!",
                    message: "Prémio resgatado com sucesso. Entraremos em contacto para entrega.",
                    okButtonText: "OK"
                });
            }
        });
    }
}