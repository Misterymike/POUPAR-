import { Observable, Frame } from '@nativescript/core';

export class HistoryViewModel extends Observable {
    constructor() {
        super();
    }

    onSimulatorTap() {
        Frame.topmost().navigate({
            moduleName: "views/simulator-page",
            transition: {
                name: "slide"
            }
        });
    }
}