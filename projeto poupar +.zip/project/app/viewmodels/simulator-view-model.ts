import { Observable, Frame } from '@nativescript/core';

export class SimulatorViewModel extends Observable {
    private _energyBill: number = 0;
    private _internetBill: number = 0;
    private _phoneBill: number = 0;
    private _savingsAmount: string = "";
    private _hasSavings: boolean = false;

    constructor() {
        super();
    }

    get energyBill(): number {
        return this._energyBill;
    }

    set energyBill(value: number) {
        if (this._energyBill !== value) {
            this._energyBill = value;
            this.notifyPropertyChange('energyBill', value);
        }
    }

    get internetBill(): number {
        return this._internetBill;
    }

    set internetBill(value: number) {
        if (this._internetBill !== value) {
            this._internetBill = value;
            this.notifyPropertyChange('internetBill', value);
        }
    }

    get phoneBill(): number {
        return this._phoneBill;
    }

    set phoneBill(value: number) {
        if (this._phoneBill !== value) {
            this._phoneBill = value;
            this.notifyPropertyChange('phoneBill', value);
        }
    }

    get savingsAmount(): string {
        return this._savingsAmount;
    }

    set savingsAmount(value: string) {
        if (this._savingsAmount !== value) {
            this._savingsAmount = value;
            this.notifyPropertyChange('savingsAmount', value);
        }
    }

    get hasSavings(): boolean {
        return this._hasSavings;
    }

    set hasSavings(value: boolean) {
        if (this._hasSavings !== value) {
            this._hasSavings = value;
            this.notifyPropertyChange('hasSavings', value);
        }
    }

    calculateSavings() {
        const totalBill = this._energyBill + this._internetBill + this._phoneBill;
        const savings = totalBill * 0.3; // 30% savings
        this.savingsAmount = `${savings.toFixed(2)}€`;
        this.hasSavings = true;
    }

    onSavingsContactTap() {
        Frame.topmost().navigate({
            moduleName: "views/contact-page",
            transition: {
                name: "slide"
            }
        });
    }
}