import { Observable, Frame } from '@nativescript/core';

export class PartnersViewModel extends Observable {
    constructor() {
        super();
    }

    onPartnerTap() {
        alert({
            title: "Ofertas Exclusivas",
            message: "Em breve você receberá um email com ofertas personalizadas deste parceiro.",
            okButtonText: "OK"
        });
    }

    onSimulatorTap() {
        Frame.topmost().navigate({
            moduleName: "views/simulator-page",
            transition: {
                name: "slide"
            }
        });
    }
}