import { Observable, Frame } from '@nativescript/core';

export class WelcomeViewModel extends Observable {
    constructor() {
        super();
    }

    onSimulatorTap() {
        Frame.topmost().navigate({
            moduleName: "views/simulator-page",
            transition: {
                name: "slide"
            }
        });
    }

    onContactTap() {
        Frame.topmost().navigate({
            moduleName: "views/contact-page",
            transition: {
                name: "slide"
            }
        });
    }

    onWalletTap() {
        Frame.topmost().navigate({
            moduleName: "views/wallet-page",
            transition: {
                name: "slide"
            }
        });
    }

    onHistoryTap() {
        Frame.topmost().navigate({
            moduleName: "views/history-page",
            transition: {
                name: "slide"
            }
        });
    }

    onPartnersTap() {
        Frame.topmost().navigate({
            moduleName: "views/partners-page",
            transition: {
                name: "slide"
            }
        });
    }
}